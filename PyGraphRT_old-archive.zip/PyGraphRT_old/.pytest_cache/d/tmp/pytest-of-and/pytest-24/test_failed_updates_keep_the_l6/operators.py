def replacement():
    return 99
raise RuntimeError('failed')
