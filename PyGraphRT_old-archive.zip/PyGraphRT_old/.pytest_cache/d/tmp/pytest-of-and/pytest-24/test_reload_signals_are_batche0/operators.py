def removed():
    return 1
def kept():
    return 2
