def value():
    return 2
def unused():
    return 100
# comment
