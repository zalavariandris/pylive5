def location():
    return __file__
