def value():
    return 2
def unused():
    return 99
# edited comment
