FLAG = 1
def value():
    return globals().get('FLAG', 0)
