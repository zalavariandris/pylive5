from math import sqrt
def outer():
    def inner():
        return 3
    return inner()
alias = outer
class Callable:
    def __call__(self):
        return 4
instance = Callable()
