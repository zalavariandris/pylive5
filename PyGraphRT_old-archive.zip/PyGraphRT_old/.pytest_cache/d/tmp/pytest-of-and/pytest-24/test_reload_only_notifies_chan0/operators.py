def value():
    return 3
def unused():
    return 99
# comment
