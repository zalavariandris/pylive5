def value():
    return "external"
