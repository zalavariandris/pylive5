def location():
    return __name__, __file__
