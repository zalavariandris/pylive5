def value():
    return 99
