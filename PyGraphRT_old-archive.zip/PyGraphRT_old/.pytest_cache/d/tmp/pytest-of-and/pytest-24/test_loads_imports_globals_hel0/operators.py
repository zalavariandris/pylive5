import math
from math import sqrt

FACTOR = 2

def helper(value):
    return math.floor(sqrt(value)) * FACTOR

def result(value: int = 9) -> int:
    return helper(value)

alias = result
